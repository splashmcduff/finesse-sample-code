Sample Client to connect to Notification Service

------------------------------------------------------------------------------
1) INTRODUCTION
------------------------------------------------------------------------------
This program can be used as a reference to write the external client in any 
language to connect to the Cisco Finesse Notification Service.

------------------------------------------------------------------------------
2) DISCLAIMER
------------------------------------------------------------------------------

This is only a sample and is NOT intended to be production quality and will not
be supported as such.  It is NOT guaranteed to be bug free. It is merely provided
as a guide for a programmer to connect to the Finesse Notification Service.

------------------------------------------------------------------------------
3) DEPENDENCIES
------------------------------------------------------------------------------

smack-core-4.3.4.jar - Smack core components.

smack-tcp-4.3.4.jar - Smack for standard XMPP connections over TCP.

smack-extensions-4.3.4.jar - Smack extensions. Classes and methods that implement support for the various XMPP XEPs (Multi-User Chat, PubSub, …) and other XMPP extensions.

smack-sasl-javax-4.3.4.jar - SASL with javax.security.sasl Use javax.security.sasl for SASL.

smack-resolver-javax-4.3.4.jar - DNS SRV with Java7 Use javax.naming for DNS SRV lookups. The javax.naming API is availabe in JavaSE since Java7.

smack-java7-4.3.4.jar - Smack for Java7 (or higher). This is a pseudo-artifact that pulls all the required dependencies to run Smack on Java 7 (or higher) JVMs. Usually you want to add additional dependencies to smack-tcp, smack-extensions and smack-experimental.

smack-im-4.3.4.jar - Smack IM. Classes and methods for XMPP-IM (RFC 6121): Roster, Chat and other functionality.

jxmpp-core-0.6.4.jar - JXMPP core components.

jxmpp-jid-0.6.4.jar - JID classes from JXMPP.

jxmpp-util-cache-0.6.4.jar - A minimalistic and efficient bounded LRU Cache with optional expiration.

minidns-core-0.3.4.jar - MiniDNS' core classes and functionality.

xpp3-1.1.4c.jar - MXP1 is a stable XmlPull parsing engine that is based on ideas from XPP and in particular XPP2 but completely revised and rewritten to take the best advantage of latest JIT JVMs such as Hotspot in JDK 1.4+.

------------------------------------------------------------------------------
4) FILES
------------------------------------------------------------------------------
- SampleXMPPClient.java: Sample Java program which has step by step process to
connect to the Notification Service and receive XML events.

------------------------------------------------------------------------------
5) Usage
------------------------------------------------------------------------------
Refer the document 'SampleNotificationService.pdf' for how to modify the program 
to suit your environment and run it.

------------------------------------------------------------------------------
6) CONTACT US
------------------------------------------------------------------------------
Questions? Visit the DevNet Finesse Microsite and post your questions in the forums.
    http://developer.cisco.com/site/finesse/
import java.util.List;

import org.jivesoftware.smack.AbstractXMPPConnection;
import org.jivesoftware.smack.tcp.XMPPTCPConnection;
import org.jivesoftware.smack.tcp.XMPPTCPConnectionConfiguration;
import org.jivesoftware.smack.ConnectionConfiguration;
import org.jivesoftware.smack.XMPPException;
import org.jivesoftware.smack.packet.Presence;
import org.jivesoftware.smackx.pubsub.Item;
import org.jivesoftware.smackx.pubsub.ItemPublishEvent;
import org.jivesoftware.smackx.pubsub.LeafNode;
import org.jivesoftware.smackx.pubsub.PubSubManager;
import org.jivesoftware.smackx.pubsub.listener.ItemEventListener;
import org.jxmpp.jid.impl.JidCreate;
import org.jxmpp.stringprep.XmppStringprepException;
import javax.net.ssl.SSLSocketFactory;


public class SampleXMPPClient {

	private AbstractXMPPConnection connection = null;
	private PubSubManager pubSubManager = null;
	private String username = "USERNAME";
	private String passwd = "PASSWORD";
	private String resource = "RESOURCE";
	private String nodeId = "/finesse/api/User/" + username;
	private String hostname = "HOSTNAME";

	public void login() throws Exception {
		System.out.println("[INFO] Building XMPP connection configuration...");
		XMPPTCPConnectionConfiguration config = XMPPTCPConnectionConfiguration.builder()
			.setXmppDomain(hostname)
			.setHost(hostname)
			.setPort(5223)
			.setUsernameAndPassword(username, passwd)
			.setResource(resource)
			.setSecurityMode(ConnectionConfiguration.SecurityMode.ifpossible)
           		.setSocketFactory(getTrustAllCertsContext().getSocketFactory())
			.setCompressionEnabled(false)
			.build();

		System.out.println("[INFO] Connecting to XMPP server " + hostname + " on port 5223...");
		connection = new XMPPTCPConnection(config);
		try {
			connection.connect();
			System.out.println("[INFO] Connected to server. Attempting login for user: " + username);
			connection.login();
			System.out.println("[SUCCESS] Login successful for user: " + username);

			pubSubManager = PubSubManager.getInstance(connection, JidCreate.domainBareFrom("pubsub." + hostname));
			subscribeImpl();
			System.out.println("[SUCCESS] Successfully Subscribed to node: " + nodeId);
		} catch (Exception e) {
			System.err.println("[ERROR] Login failed for user: " + username);
			System.err.println("[ERROR] Exception: " + e.getClass().getName() + ": " + e.getMessage());
			if (e.getCause() != null) {
				System.err.println("[ERROR] Cause: " + e.getCause().getClass().getName() + ": " + e.getCause().getMessage());
			}
			throw e;
		}
	}

	// Trust all SSL certificates (for testing only!)
	private static javax.net.ssl.SSLContext getTrustAllCertsContext() throws Exception {
                javax.net.ssl.SSLContext sc = javax.net.ssl.SSLContext.getInstance("TLS");
                sc.init(null, new javax.net.ssl.TrustManager[]{
                        new javax.net.ssl.X509TrustManager() {
                                public void checkClientTrusted(java.security.cert.X509Certificate[] chain, String authType) {}
                                public void checkServerTrusted(java.security.cert.X509Certificate[] chain, String authType) {}
                                public java.security.cert.X509Certificate[] getAcceptedIssuers() { return new java.security.cert.X509Certificate[0]; }
                        }
                }, new java.security.SecureRandom());
                return sc;
        }

	private void subscribeImpl() throws Exception {
		System.out.println("[INFO] Subscribing to node: " + nodeId);
		LeafNode node = (LeafNode) pubSubManager.getNode(nodeId);
		node.addItemEventListener(new ItemEventListener<Item>() {
			@Override
			public void handlePublishedItems(ItemPublishEvent<Item> itemsPublished) {
				System.out.println("[EVENT] Received published items for node: " + nodeId);
				List<Item> items = itemsPublished.getItems();
				for (Item item : items) {
					System.out.println("[EVENT] Item: " + item.toString());
				}
			}
		});
	}

	public void logout() {
		if (connection != null && connection.isConnected()) {
			connection.disconnect();
			System.out.println("Successfully disconnected");
		}
	}

	public static void main(String[] args) throws Exception {
		SampleXMPPClient client = new SampleXMPPClient();
		client.login();
		System.out.println("Waiting for event");
		Thread.sleep(Long.MAX_VALUE);
	}

}

